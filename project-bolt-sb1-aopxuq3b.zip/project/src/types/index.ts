export interface Product {
  id: string;
  name: string;
  shortDescription: string;
  longDescription: string;
  features: string[];
  image: string;
  slug: string;
}

export interface Project {
  id: string;
  title: string;
  description: string;
  location: string;
  image: string;
  slug: string;
}

export interface TeamMember {
  id: string;
  name: string;
  position: string;
  bio: string;
  image: string;
}

export interface FAQ {
  id: string;
  question: string;
  answer: string;
  category: string;
}