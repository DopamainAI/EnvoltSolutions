import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { CheckCircle, ArrowLeft } from 'lucide-react';
import Button from '../components/ui/Button';
import { PRODUCTS } from '../utils/constants';

const ProductDetail: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  
  // Find the product based on the slug
  const product = PRODUCTS.find(p => p.slug === slug);
  
  // If product not found, show error page
  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center max-w-md p-8">
          <h1 className="text-3xl font-bold mb-4">Product Not Found</h1>
          <p className="text-gray-600 mb-6">
            The product you're looking for doesn't exist or may have been moved.
          </p>
          <Button variant="primary">
            <Link to="/products">View All Products</Link>
          </Button>
        </div>
      </div>
    );
  }
  
  return (
    <div>
      {/* Hero Section */}
      <section className="bg-[#111827] py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl">
            <Link
              to="/products"
              className="inline-flex items-center text-gray-300 hover:text-white mb-6"
            >
              <ArrowLeft size={16} className="mr-2" />
              Back to All Products
            </Link>
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              {product.name}
            </h1>
            <p className="text-xl text-gray-300">
              {product.shortDescription}
            </p>
          </div>
        </div>
      </section>
      
      {/* Product Overview */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <img
                src={product.image}
                alt={product.name}
                className="rounded-lg shadow-lg w-full"
              />
            </div>
            
            <div>
              <h2 className="text-3xl font-bold mb-6">Overview</h2>
              <p className="text-gray-600 mb-8">{product.longDescription}</p>
              
              <h3 className="text-xl font-semibold mb-4">Key Features</h3>
              <ul className="space-y-3 mb-8">
                {product.features.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    <CheckCircle size={20} className="text-[#34D399] mr-3 flex-shrink-0 mt-0.5" />
                    <span className="text-gray-600">{feature}</span>
                  </li>
                ))}
              </ul>
              
              <div className="flex flex-wrap gap-4">
                <Button variant="primary" size="lg">
                  <Link to="/contact">Request Quote</Link>
                </Button>
                <Button variant="outline" size="lg">
                  <Link to="/contact">Ask a Question</Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Technical Specifications */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-8 text-center">
              Technical Specifications
            </h2>
            
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="divide-y divide-gray-200">
                <div className="grid grid-cols-1 md:grid-cols-3 py-4 px-6">
                  <div className="font-semibold md:col-span-1">
                    Energy Density
                  </div>
                  <div className="text-gray-600 md:col-span-2">
                    400-500 Wh/kg (50% higher than lithium-ion)
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 py-4 px-6">
                  <div className="font-semibold md:col-span-1">
                    Cycle Life
                  </div>
                  <div className="text-gray-600 md:col-span-2">
                    5,000+ cycles (at 80% depth of discharge)
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 py-4 px-6">
                  <div className="font-semibold md:col-span-1">
                    Operating Temperature
                  </div>
                  <div className="text-gray-600 md:col-span-2">
                    -30°C to 60°C
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 py-4 px-6">
                  <div className="font-semibold md:col-span-1">
                    Charging Rate
                  </div>
                  <div className="text-gray-600 md:col-span-2">
                    Fast charging capable (80% in 15 minutes)
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 py-4 px-6">
                  <div className="font-semibold md:col-span-1">
                    Safety Features
                  </div>
                  <div className="text-gray-600 md:col-span-2">
                    Non-flammable solid electrolyte, thermal management system, short circuit protection
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 py-4 px-6">
                  <div className="font-semibold md:col-span-1">
                    Warranty
                  </div>
                  <div className="text-gray-600 md:col-span-2">
                    10 years standard, extended options available
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Applications */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">
              Common Applications
            </h2>
            <p className="text-gray-600 max-w-3xl mx-auto">
              Our {product.name} is designed to excel in various applications, providing reliable, safe, and efficient energy storage.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-gray-50 rounded-lg p-6 text-center">
              <div className="w-16 h-16 bg-[#34D399] bg-opacity-10 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-[#34D399]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">Residential</h3>
              <p className="text-gray-600">
                Home energy storage, backup power systems, and integration with solar installations.
              </p>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-6 text-center">
              <div className="w-16 h-16 bg-[#34D399] bg-opacity-10 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-[#34D399]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">Commercial</h3>
              <p className="text-gray-600">
                Office buildings, retail spaces, and data centers requiring reliable power solutions.
              </p>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-6 text-center">
              <div className="w-16 h-16 bg-[#34D399] bg-opacity-10 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-[#34D399]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">Utility</h3>
              <p className="text-gray-600">
                Grid stabilization, peak shaving, and renewable energy integration for utilities.
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Related Products */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">
              Related Products
            </h2>
            <p className="text-gray-600 max-w-3xl mx-auto">
              Explore our other innovative energy storage solutions.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {PRODUCTS.filter(p => p.id !== product.id).slice(0, 3).map(relatedProduct => (
              <div 
                key={relatedProduct.id} 
                className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 hover:-translate-y-2"
              >
                <img 
                  src={relatedProduct.image} 
                  alt={relatedProduct.name} 
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2">{relatedProduct.name}</h3>
                  <p className="text-gray-600 mb-4">{relatedProduct.shortDescription}</p>
                  <Link 
                    to={`/products/${relatedProduct.slug}`} 
                    className="text-[#34D399] font-medium inline-flex items-center hover:underline"
                  >
                    Learn More
                    <ArrowLeft size={16} className="ml-2 rotate-180" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-16 bg-[#111827] text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6">
              Ready to Transform Your Energy Storage?
            </h2>
            <p className="text-xl mb-8">
              Contact us today to discuss how {product.name} can meet your specific needs.
            </p>
            <Button variant="primary" size="lg">
              <Link to="/contact">Get a Quote</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ProductDetail;