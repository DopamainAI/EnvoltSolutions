import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search } from 'lucide-react';
import Accordion from '../components/ui/Accordion';
import Button from '../components/ui/Button';
import { FAQS } from '../utils/constants';

const Faq: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  
  // Get unique categories
  const categories = Array.from(new Set(FAQS.map(faq => faq.category)));
  
  // Filter FAQs based on search and category
  const filteredFAQs = FAQS.filter(faq => {
    const matchesSearch = searchQuery === '' || 
      faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      faq.answer.toLowerCase().includes(searchQuery.toLowerCase());
      
    const matchesCategory = activeCategory === null || faq.category === activeCategory;
    
    return matchesSearch && matchesCategory;
  });
  
  // Transform FAQs for Accordion component
  const accordionItems = filteredFAQs.map(faq => ({
    id: faq.id,
    title: faq.question,
    content: <p className="text-gray-600">{faq.answer}</p>
  }));
  
  return (
    <div>
      {/* Hero Section */}
      <section className="bg-[#111827] py-20 md:py-28">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Frequently Asked Questions
            </h1>
            <p className="text-xl text-gray-300 mb-8">
              Find answers to common questions about our solid-state battery technology and products.
            </p>
            
            {/* Search Bar */}
            <div className="relative max-w-xl mx-auto">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search size={20} className="text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Search for questions..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-3 rounded-lg bg-white bg-opacity-10 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#34D399]"
              />
            </div>
          </div>
        </div>
      </section>
      
      {/* FAQ Content */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Category Sidebar */}
            <div className="lg:col-span-1">
              <div className="bg-gray-50 rounded-lg p-6">
                <h3 className="text-lg font-semibold mb-4">Categories</h3>
                <ul className="space-y-2">
                  <li>
                    <button 
                      className={`w-full text-left py-2 px-3 rounded-md transition-colors ${
                        activeCategory === null 
                          ? 'bg-[#34D399] text-white' 
                          : 'hover:bg-gray-100'
                      }`}
                      onClick={() => setActiveCategory(null)}
                    >
                      All Categories
                    </button>
                  </li>
                  {categories.map(category => (
                    <li key={category}>
                      <button 
                        className={`w-full text-left py-2 px-3 rounded-md transition-colors ${
                          activeCategory === category 
                            ? 'bg-[#34D399] text-white' 
                            : 'hover:bg-gray-100'
                        }`}
                        onClick={() => setActiveCategory(category)}
                      >
                        {category}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
            
            {/* FAQ Accordion */}
            <div className="lg:col-span-3">
              {filteredFAQs.length > 0 ? (
                <Accordion items={accordionItems} />
              ) : (
                <div className="text-center bg-gray-50 rounded-lg p-12">
                  <h3 className="text-xl font-semibold mb-2">No Questions Found</h3>
                  <p className="text-gray-600 mb-6">
                    We couldn't find any questions matching your search. Please try a different query or browse by category.
                  </p>
                  <Button 
                    variant="primary"
                    onClick={() => {
                      setSearchQuery('');
                      setActiveCategory(null);
                    }}
                  >
                    Reset Filters
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
      
      {/* Still Have Questions */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="bg-white rounded-lg shadow-md p-8 max-w-3xl mx-auto text-center">
            <h2 className="text-2xl font-bold mb-4">Still Have Questions?</h2>
            <p className="text-gray-600 mb-6">
              Can't find the answer you're looking for? Please contact our friendly team.
            </p>
            <Button variant="primary">
              <Link to="/contact">Contact Us</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Faq;