import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, MapPin, Calendar, CheckCircle } from 'lucide-react';
import Button from '../components/ui/Button';
import { PROJECTS } from '../utils/constants';

const ProjectDetail: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  
  // Find the project based on the slug
  const project = PROJECTS.find(p => p.slug === slug);
  
  // If project not found, show error page
  if (!project) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center max-w-md p-8">
          <h1 className="text-3xl font-bold mb-4">Project Not Found</h1>
          <p className="text-gray-600 mb-6">
            The project you're looking for doesn't exist or may have been moved.
          </p>
          <Button variant="primary">
            <Link to="/projects">View All Projects</Link>
          </Button>
        </div>
      </div>
    );
  }
  
  // Get sample project images based on project slug
  const getProjectImages = () => {
    if (project.slug === 'neom-charging') {
      return [
        'https://i.ibb.co/fsmwSS6/Neom-Charging-Unit.jpg',
        'https://i.ibb.co/ynp9L5hV/En-Pack-Saudi-Case-1.jpg',
        'https://i.ibb.co/nqgT3rXd/En-Pack-Saudi-Case-2.jpg'
      ];
    }
    
    return [
      project.image,
      'https://i.ibb.co/v6WfxqMs/En-Pack-vs-Lith-Img-5.png',
      'https://i.ibb.co/M5h8tdM2/En-Pack-Cabinet.png'
    ];
  };
  
  const projectImages = getProjectImages();
  
  return (
    <div>
      {/* Hero Section */}
      <section className="bg-[#111827] py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl">
            <Link
              to="/projects"
              className="inline-flex items-center text-gray-300 hover:text-white mb-6"
            >
              <ArrowLeft size={16} className="mr-2" />
              Back to All Projects
            </Link>
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              {project.title}
            </h1>
            <div className="flex items-center text-gray-300 mb-6">
              <MapPin size={20} className="mr-2" />
              <span>{project.location}</span>
              <span className="mx-3">•</span>
              <Calendar size={20} className="mr-2" />
              <span>Completed 2023</span>
            </div>
            <p className="text-xl text-gray-300">
              {project.description}
            </p>
          </div>
        </div>
      </section>
      
      {/* Project Gallery */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {projectImages.map((image, index) => (
              <img
                key={index}
                src={image}
                alt={`${project.title} - Image ${index + 1}`}
                className="w-full h-64 object-cover rounded-lg shadow-md hover:shadow-lg transition-shadow"
              />
            ))}
          </div>
        </div>
      </section>
      
      {/* Project Details */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
              <div className="lg:col-span-2">
                <h2 className="text-3xl font-bold mb-6">Project Overview</h2>
                
                <div className="space-y-6">
                  <div>
                    <h3 className="text-xl font-semibold mb-3">The Challenge</h3>
                    <p className="text-gray-600">
                      {project.slug === 'neom-charging'
                        ? "NEOM required a reliable, high-capacity energy storage solution that could integrate with renewable sources and operate in extreme desert conditions. The system needed to be modular, scalable, and capable of withstanding temperatures of up to 50°C while maintaining optimal performance."
                        : "The client needed a reliable energy storage solution that could provide consistent power in challenging environmental conditions. Traditional lithium-ion batteries were proving inadequate due to safety concerns, limited lifespan, and performance degradation in extreme temperatures."}
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="text-xl font-semibold mb-3">Our Solution</h3>
                    <p className="text-gray-600">
                      {project.slug === 'neom-charging'
                        ? "We implemented a customized EnPack solution with enhanced thermal management capabilities specifically designed for desert environments. The system included remote monitoring and diagnostics to ensure optimal performance at all times. Our solid-state technology eliminated safety concerns associated with traditional lithium-ion batteries."
                        : "We deployed our advanced solid-state battery technology, customized to meet the specific needs of the project. Our solution provided higher energy density, longer lifespan, and superior safety compared to conventional alternatives. The system was designed with modularity in mind, allowing for easy scalability as energy needs grow."}
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="text-xl font-semibold mb-3">Results & Benefits</h3>
                    <ul className="space-y-3">
                      <li className="flex items-start">
                        <CheckCircle size={20} className="text-[#34D399] mr-3 flex-shrink-0 mt-0.5" />
                        <span className="text-gray-600">30% reduction in overall energy costs</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle size={20} className="text-[#34D399] mr-3 flex-shrink-0 mt-0.5" />
                        <span className="text-gray-600">40% smaller footprint compared to competing solutions</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle size={20} className="text-[#34D399] mr-3 flex-shrink-0 mt-0.5" />
                        <span className="text-gray-600">99.9% uptime since installation</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle size={20} className="text-[#34D399] mr-3 flex-shrink-0 mt-0.5" />
                        <span className="text-gray-600">Zero safety incidents reported</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle size={20} className="text-[#34D399] mr-3 flex-shrink-0 mt-0.5" />
                        <span className="text-gray-600">Reliable performance in temperatures up to 50°C</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              
              <div>
                <div className="bg-white rounded-lg shadow-md p-6">
                  <h3 className="text-xl font-semibold mb-4">Project Details</h3>
                  
                  <div className="space-y-4">
                    <div>
                      <p className="text-sm text-gray-500">Client</p>
                      <p className="font-medium">
                        {project.slug === 'neom-charging' 
                          ? 'NEOM Development Authority' 
                          : project.slug === 'etisalat-storage'
                            ? 'Etisalat'
                            : 'Confidential'
                        }
                      </p>
                    </div>
                    
                    <div>
                      <p className="text-sm text-gray-500">Location</p>
                      <p className="font-medium">{project.location}</p>
                    </div>
                    
                    <div>
                      <p className="text-sm text-gray-500">Project Type</p>
                      <p className="font-medium">
                        {project.slug === 'neom-charging' 
                          ? 'EV Charging Infrastructure' 
                          : project.slug === 'solar-site-uae'
                            ? 'Renewable Energy Storage'
                            : 'Energy Storage Solution'
                        }
                      </p>
                    </div>
                    
                    <div>
                      <p className="text-sm text-gray-500">Capacity</p>
                      <p className="font-medium">
                        {project.slug === 'neom-charging' 
                          ? '500 kWh' 
                          : project.slug === 'solar-site-uae'
                            ? '2 MWh'
                            : '250 kWh'
                        }
                      </p>
                    </div>
                    
                    <div>
                      <p className="text-sm text-gray-500">Year Completed</p>
                      <p className="font-medium">2023</p>
                    </div>
                    
                    <div>
                      <p className="text-sm text-gray-500">Products Used</p>
                      <p className="font-medium">
                        {project.slug === 'neom-charging' 
                          ? 'EnPack, EnCharge' 
                          : project.slug === 'solar-site-uae'
                            ? 'EnSaga, EnWall'
                            : 'EnCap, EnWall'
                        }
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Client Testimonial */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <blockquote className="bg-gray-50 rounded-lg p-8 shadow-md">
              <svg className="w-12 h-12 text-[#34D399] opacity-20 mb-4" fill="currentColor" viewBox="0 0 32 32">
                <path d="M14.924 5.636v5.669c0 3.898-2.176 7.549-5.772 9.737l-3.25-3.852c1.464-1.158 2.576-2.673 3.261-4.448h-3.879v-7.107h9.64zM30.594 5.636v5.669c0 3.898-2.176 7.549-5.772 9.737l-3.25-3.852c1.464-1.158 2.576-2.673 3.261-4.448h-3.879v-7.107h9.64z" />
              </svg>
              
              <p className="text-lg text-gray-600 italic mb-6">
                "Envolt Solutions delivered exactly what we needed - a reliable, high-performance energy storage system that has exceeded our expectations. Their solid-state battery technology has proven to be a game-changer for our operations, providing consistent power even in the most challenging conditions."
              </p>
              
              <div className="flex items-center">
                <div>
                  <p className="font-bold text-gray-800">Ahmed Al-Mansour</p>
                  <p className="text-gray-500">
                    {project.slug === 'neom-charging' 
                      ? 'Chief Technology Officer, NEOM' 
                      : project.slug === 'etisalat-storage'
                        ? 'Operations Director, Etisalat'
                        : 'Project Director'
                    }
                  </p>
                </div>
              </div>
            </blockquote>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-16 bg-[#111827] text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6">
              Ready to Start Your Project?
            </h2>
            <p className="text-xl mb-8">
              Contact us today to discuss how our solid-state battery solutions can benefit your specific application.
            </p>
            <Button variant="primary" size="lg">
              <Link to="/contact">Contact Our Team</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ProjectDetail;