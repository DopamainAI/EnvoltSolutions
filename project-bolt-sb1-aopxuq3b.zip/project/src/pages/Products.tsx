import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle } from 'lucide-react';
import Card, { CardContent } from '../components/ui/Card';
import Button from '../components/ui/Button';
import { PRODUCTS } from '../utils/constants';

const Products: React.FC = () => {
  return (
    <div>
      {/* Hero Section */}
      <section className="bg-[#111827] py-20 md:py-28">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Our Products
            </h1>
            <p className="text-xl text-gray-300 mb-8">
              Discover our innovative solid-state battery solutions designed for a wide range of applications.
            </p>
          </div>
        </div>
      </section>
      
      {/* Products Overview */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-16">
            {PRODUCTS.map((product, index) => {
              // Alternate layout direction for even/odd products
              const isEven = index % 2 === 0;
              
              return (
                <div 
                  key={product.id} 
                  className={`flex flex-col md:flex-row md:items-center gap-8 ${
                    isEven ? 'md:flex-row' : 'md:flex-row-reverse'
                  }`}
                >
                  <div className="md:w-1/2">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="rounded-lg shadow-md w-full h-auto object-cover"
                    />
                  </div>
                  
                  <div className="md:w-1/2">
                    <h2 className="text-3xl font-bold mb-4">{product.name}</h2>
                    <p className="text-gray-600 mb-6">{product.longDescription}</p>
                    
                    <h3 className="text-lg font-semibold mb-3">Key Features:</h3>
                    <ul className="space-y-2 mb-6">
                      {product.features.map((feature, idx) => (
                        <li key={idx} className="flex items-start">
                          <CheckCircle size={20} className="text-[#34D399] mr-2 flex-shrink-0 mt-0.5" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                    
                    <Button variant="primary">
                      <Link to={`/products/${product.slug}`} className="flex items-center">
                        Learn More
                        <ArrowRight size={16} className="ml-2" />
                      </Link>
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>
      
      {/* Comparison Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              How We Compare
            </h2>
            <p className="text-gray-600 max-w-3xl mx-auto">
              See how our solid-state battery technology stacks up against traditional lithium-ion batteries.
            </p>
          </div>
          
          <div className="overflow-x-auto">
            <table className="min-w-full bg-white rounded-lg shadow-md">
              <thead>
                <tr className="bg-gray-100">
                  <th className="py-4 px-6 text-left">Feature</th>
                  <th className="py-4 px-6 text-center">Envolt Solid-State</th>
                  <th className="py-4 px-6 text-center">Traditional Lithium-Ion</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b">
                  <td className="py-4 px-6 font-medium">Safety</td>
                  <td className="py-4 px-6 text-center text-[#34D399]">
                    <div className="flex items-center justify-center">
                      <CheckCircle size={20} className="mr-2" />
                      Excellent - No thermal runaway risk
                    </div>
                  </td>
                  <td className="py-4 px-6 text-center text-gray-600">
                    Potential fire and explosion risks
                  </td>
                </tr>
                <tr className="border-b">
                  <td className="py-4 px-6 font-medium">Energy Density</td>
                  <td className="py-4 px-6 text-center text-[#34D399]">
                    <div className="flex items-center justify-center">
                      <CheckCircle size={20} className="mr-2" />
                      Up to 50% higher
                    </div>
                  </td>
                  <td className="py-4 px-6 text-center text-gray-600">
                    Standard
                  </td>
                </tr>
                <tr className="border-b">
                  <td className="py-4 px-6 font-medium">Lifespan</td>
                  <td className="py-4 px-6 text-center text-[#34D399]">
                    <div className="flex items-center justify-center">
                      <CheckCircle size={20} className="mr-2" />
                      10-15 years
                    </div>
                  </td>
                  <td className="py-4 px-6 text-center text-gray-600">
                    3-5 years
                  </td>
                </tr>
                <tr className="border-b">
                  <td className="py-4 px-6 font-medium">Charging Speed</td>
                  <td className="py-4 px-6 text-center text-[#34D399]">
                    <div className="flex items-center justify-center">
                      <CheckCircle size={20} className="mr-2" />
                      Fast - 80% in 15 minutes
                    </div>
                  </td>
                  <td className="py-4 px-6 text-center text-gray-600">
                    Moderate - 80% in 30+ minutes
                  </td>
                </tr>
                <tr>
                  <td className="py-4 px-6 font-medium">Environmental Impact</td>
                  <td className="py-4 px-6 text-center text-[#34D399]">
                    <div className="flex items-center justify-center">
                      <CheckCircle size={20} className="mr-2" />
                      Minimal - Reduced toxic materials
                    </div>
                  </td>
                  <td className="py-4 px-6 text-center text-gray-600">
                    Higher - Contains more harmful materials
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="bg-[#111827] rounded-xl overflow-hidden">
            <div className="grid grid-cols-1 md:grid-cols-2">
              <div className="p-8 md:p-12 flex flex-col justify-center">
                <h2 className="text-3xl font-bold text-white mb-4">
                  Ready to Transform Your Energy Storage?
                </h2>
                <p className="text-gray-300 mb-6">
                  Contact us today to discuss how our products can meet your specific energy storage needs.
                </p>
                <div className="flex flex-wrap gap-4">
                  <Button variant="primary">
                    <Link to="/contact">Get a Quote</Link>
                  </Button>
                  <Button variant="outline">
                    <Link to="/projects">See Case Studies</Link>
                  </Button>
                </div>
              </div>
              
              <div className="hidden md:block">
                <img 
                  src="https://i.ibb.co/v6WfxqMs/En-Pack-vs-Lith-Img-5.png" 
                  alt="Envolt Battery Comparison" 
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Products;