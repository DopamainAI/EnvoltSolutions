import React from 'react';
import { Link } from 'react-router-dom';
import { Award, Target, Users, Globe } from 'lucide-react';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';
import { TEAM_MEMBERS } from '../utils/constants';

const About: React.FC = () => {
  return (
    <div>
      {/* Hero Section */}
      <section className="bg-[#111827] py-20 md:py-28">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              About Envolt Solutions
            </h1>
            <p className="text-xl text-gray-300">
              Revolutionizing energy storage through cutting-edge solid-state battery technology.
            </p>
          </div>
        </div>
      </section>
      
      {/* Our Story */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6">Our Story</h2>
              <p className="text-gray-600 mb-4">
                Founded in 2015, Envolt Solutions began with a mission to address the limitations of conventional lithium-ion batteries. Our founders, a team of materials scientists and energy experts, recognized the need for safer, more efficient, and environmentally friendly energy storage solutions.
              </p>
              <p className="text-gray-600 mb-4">
                After years of intensive research and development, we successfully commercialized our proprietary solid-state battery technology, which eliminates the flammable liquid electrolytes found in traditional batteries, dramatically enhancing safety and performance.
              </p>
              <p className="text-gray-600">
                Today, Envolt Solutions is at the forefront of the solid-state battery revolution, providing innovative energy storage solutions to customers across North America and beyond. Our team continues to push the boundaries of what's possible in energy storage technology.
              </p>
            </div>
            
            <div className="relative">
              <img 
                src="https://i.ibb.co/M5h8tdM2/En-Pack-Cabinet.png" 
                alt="Envolt Products" 
                className="rounded-lg shadow-lg"
              />
              <div className="absolute -bottom-6 -left-6 bg-[#34D399] text-white px-6 py-4 rounded-lg shadow-lg">
                <p className="text-3xl font-bold">10+ Years</p>
                <p>of Research & Innovation</p>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Our Values */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Our Core Values
            </h2>
            <p className="text-gray-600 max-w-3xl mx-auto">
              These principles guide every aspect of our business, from research and development to customer service.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="text-center p-6 h-full" hoverEffect>
              <div className="bg-[#34D399] bg-opacity-10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award size={28} className="text-[#34D399]" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Excellence</h3>
              <p className="text-gray-600">
                We are committed to maintaining the highest standards in all aspects of our work, from product development to customer service.
              </p>
            </Card>
            
            <Card className="text-center p-6 h-full" hoverEffect>
              <div className="bg-[#34D399] bg-opacity-10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Target size={28} className="text-[#34D399]" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Innovation</h3>
              <p className="text-gray-600">
                We continuously push the boundaries of what's possible in energy storage technology, driving progress through creativity and forward thinking.
              </p>
            </Card>
            
            <Card className="text-center p-6 h-full" hoverEffect>
              <div className="bg-[#34D399] bg-opacity-10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Globe size={28} className="text-[#34D399]" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Sustainability</h3>
              <p className="text-gray-600">
                We are dedicated to developing environmentally responsible technologies that contribute to a cleaner, more sustainable future.
              </p>
            </Card>
            
            <Card className="text-center p-6 h-full" hoverEffect>
              <div className="bg-[#34D399] bg-opacity-10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users size={28} className="text-[#34D399]" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Collaboration</h3>
              <p className="text-gray-600">
                We believe in the power of teamwork and partnership, working closely with our clients and partners to achieve shared goals.
              </p>
            </Card>
          </div>
        </div>
      </section>
      
      {/* Our Team */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Meet Our Leadership Team
            </h2>
            <p className="text-gray-600 max-w-3xl mx-auto">
              Our diverse team of experts brings decades of combined experience in battery technology, materials science, and sustainable energy.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {TEAM_MEMBERS.map(member => (
              <Card key={member.id} className="overflow-hidden" hoverEffect>
                <img 
                  src={member.image} 
                  alt={member.name} 
                  className="w-full h-64 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-1">{member.name}</h3>
                  <p className="text-[#34D399] font-medium mb-4">{member.position}</p>
                  <p className="text-gray-600">{member.bio}</p>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>
      
      {/* Achievements */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Our Achievements
            </h2>
            <p className="text-gray-600 max-w-3xl mx-auto">
              We're proud of the milestones we've reached on our journey to revolutionize energy storage.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="text-4xl font-bold text-[#34D399] mb-2">50+</div>
              <p className="text-gray-600 font-medium">Successful Projects</p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="text-4xl font-bold text-[#34D399] mb-2">12</div>
              <p className="text-gray-600 font-medium">Patents Filed</p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="text-4xl font-bold text-[#34D399] mb-2">15+</div>
              <p className="text-gray-600 font-medium">Countries Served</p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="text-4xl font-bold text-[#34D399] mb-2">3</div>
              <p className="text-gray-600 font-medium">Industry Awards</p>
            </div>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-16 bg-[#111827] text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Join Us in Reshaping the Future of Energy
            </h2>
            <p className="text-xl mb-8">
              Whether you're looking for innovative energy storage solutions or career opportunities, we'd love to hear from you.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Button variant="primary" size="lg">
                <Link to="/contact">Contact Us</Link>
              </Button>
              <Button variant="outline" size="lg">
                <Link to="/products">Explore Products</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;