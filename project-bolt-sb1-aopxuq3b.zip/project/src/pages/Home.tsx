import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Battery, Leaf, Zap, Clock } from 'lucide-react';
import ImageSlider from '../components/ui/ImageSlider';
import Button from '../components/ui/Button';
import Card, { CardContent } from '../components/ui/Card';
import { PRODUCTS, PROJECTS } from '../utils/constants';

const Home: React.FC = () => {
  const heroImages = [
    'https://i.ibb.co/fBxLYm0/pexels-lukas-296236-2048x1356.jpg',
    'https://i.ibb.co/Frx4x1j/Untitled-design.jpg',
    'https://i.ibb.co/m54ktZSH/En-Pack-Header-Img-2.jpg'
  ];
  
  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-screen">
        <ImageSlider 
          images={heroImages} 
          className="h-full"
        />
        
        <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6">
                The Future of Battery Technology
              </h1>
              <p className="text-xl text-white mb-8">
                Revolutionizing energy storage with advanced solid-state battery technology that's safer, longer-lasting, and more environmentally friendly.
              </p>
              <div className="flex flex-wrap gap-4">
                <Button variant="primary" size="lg">
                  Explore Products
                </Button>
                <Button variant="outline" size="lg">
                  Learn More
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Why Choose Solid-State Batteries?
            </h2>
            <p className="text-gray-600 max-w-3xl mx-auto">
              Our solid-state battery technology offers significant advantages over traditional lithium-ion batteries, making it the ideal choice for a wide range of applications.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="text-center p-6" hoverEffect>
              <div className="bg-[#34D399] bg-opacity-10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Battery size={28} className="text-[#34D399]" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Higher Energy Density</h3>
              <p className="text-gray-600">
                Store more energy in a smaller space, allowing for more compact and efficient designs.
              </p>
            </Card>
            
            <Card className="text-center p-6" hoverEffect>
              <div className="bg-[#34D399] bg-opacity-10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Leaf size={28} className="text-[#34D399]" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Environmentally Friendly</h3>
              <p className="text-gray-600">
                Manufactured without toxic materials, making them safer for the environment.
              </p>
            </Card>
            
            <Card className="text-center p-6" hoverEffect>
              <div className="bg-[#34D399] bg-opacity-10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Zap size={28} className="text-[#34D399]" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Enhanced Safety</h3>
              <p className="text-gray-600">
                No risk of thermal runaway or fires, making them safer for all applications.
              </p>
            </Card>
            
            <Card className="text-center p-6" hoverEffect>
              <div className="bg-[#34D399] bg-opacity-10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock size={28} className="text-[#34D399]" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Longer Lifespan</h3>
              <p className="text-gray-600">
                Last up to 3 times longer than traditional batteries, reducing replacement costs.
              </p>
            </Card>
          </div>
        </div>
      </section>
      
      {/* Products Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Our Product Range
            </h2>
            <p className="text-gray-600 max-w-3xl mx-auto">
              Discover our innovative solid-state battery solutions designed for a wide range of applications.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {PRODUCTS.slice(0, 4).map(product => (
              <Card key={product.id} hoverEffect className="overflow-hidden h-full">
                <div className="flex flex-col h-full">
                  <img 
                    src={product.image} 
                    alt={product.name} 
                    className="w-full h-48 object-cover"
                  />
                  <CardContent className="flex flex-col flex-grow">
                    <h3 className="text-xl font-bold mb-2">{product.name}</h3>
                    <p className="text-gray-600 mb-4">{product.shortDescription}</p>
                    <div className="mt-auto">
                      <Link 
                        to={`/products/${product.slug}`} 
                        className="text-[#34D399] font-medium inline-flex items-center hover:underline"
                      >
                        Learn More
                        <ArrowRight size={16} className="ml-1" />
                      </Link>
                    </div>
                  </CardContent>
                </div>
              </Card>
            ))}
          </div>
          
          <div className="text-center mt-10">
            <Button variant="primary" size="lg">
              <Link to="/products">View All Products</Link>
            </Button>
          </div>
        </div>
      </section>
      
      {/* Projects Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Featured Projects
            </h2>
            <p className="text-gray-600 max-w-3xl mx-auto">
              See how our technology is making a difference in real-world applications.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {PROJECTS.slice(0, 3).map(project => (
              <Card key={project.id} hoverEffect className="overflow-hidden h-full">
                <div className="flex flex-col h-full">
                  <img 
                    src={project.image} 
                    alt={project.title} 
                    className="w-full h-48 object-cover"
                  />
                  <CardContent className="flex flex-col flex-grow">
                    <h3 className="text-xl font-bold mb-2">{project.title}</h3>
                    <p className="text-sm text-[#34D399] mb-2">{project.location}</p>
                    <p className="text-gray-600 mb-4">{project.description}</p>
                    <div className="mt-auto">
                      <Link 
                        to={`/projects/${project.slug}`} 
                        className="text-[#34D399] font-medium inline-flex items-center hover:underline"
                      >
                        View Case Study
                        <ArrowRight size={16} className="ml-1" />
                      </Link>
                    </div>
                  </CardContent>
                </div>
              </Card>
            ))}
          </div>
          
          <div className="text-center mt-10">
            <Button variant="primary" size="lg">
              <Link to="/projects">Explore All Projects</Link>
            </Button>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-16 bg-[#111827] text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Ready to Upgrade Your Energy Storage?
            </h2>
            <p className="text-xl mb-8">
              Contact us today to discuss how our solid-state battery solutions can meet your specific needs.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Button variant="primary" size="lg">
                <Link to="/contact">Get in Touch</Link>
              </Button>
              <Button variant="outline" size="lg">
                <Link to="/products">Browse Products</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;