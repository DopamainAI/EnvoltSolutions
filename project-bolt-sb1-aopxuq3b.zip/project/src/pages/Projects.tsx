import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, ArrowRight } from 'lucide-react';
import Card, { CardContent } from '../components/ui/Card';
import Button from '../components/ui/Button';
import { PROJECTS } from '../utils/constants';

const Projects: React.FC = () => {
  return (
    <div>
      {/* Hero Section */}
      <section className="bg-[#111827] py-20 md:py-28">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Our Projects
            </h1>
            <p className="text-xl text-gray-300 mb-8">
              See how our solid-state battery technology is being implemented across various industries and applications.
            </p>
          </div>
        </div>
      </section>
      
      {/* Projects Grid */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {PROJECTS.map(project => (
              <Card key={project.id} hoverEffect className="overflow-hidden h-full">
                <div className="flex flex-col h-full">
                  <img 
                    src={project.image} 
                    alt={project.title} 
                    className="w-full h-56 object-cover"
                  />
                  <CardContent className="flex flex-col flex-grow">
                    <div className="flex items-center mb-3">
                      <MapPin size={18} className="text-[#34D399] mr-2" />
                      <span className="text-gray-600">{project.location}</span>
                    </div>
                    <h3 className="text-xl font-bold mb-3">{project.title}</h3>
                    <p className="text-gray-600 mb-4">{project.description}</p>
                    <div className="mt-auto">
                      <Link 
                        to={`/projects/${project.slug}`} 
                        className="text-[#34D399] font-medium inline-flex items-center hover:underline"
                      >
                        View Case Study
                        <ArrowRight size={16} className="ml-1" />
                      </Link>
                    </div>
                  </CardContent>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>
      
      {/* Featured Case Study */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Featured Case Study
            </h2>
            <p className="text-gray-600 max-w-3xl mx-auto">
              A closer look at our project implementation in Saudi Arabia, showcasing the benefits of our EnPack technology.
            </p>
          </div>
          
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2">
              <div className="p-8 lg:p-12">
                <h3 className="text-2xl font-bold mb-4">
                  EnPack Implementation at NEOM
                </h3>
                <p className="text-gray-600 mb-6">
                  Our installation at NEOM's innovative city project demonstrates the versatility and efficiency of our EnPack systems. This project represents a significant advancement in sustainable urban energy solutions.
                </p>
                
                <div className="space-y-4 mb-6">
                  <div className="border-l-4 border-[#34D399] pl-4">
                    <h4 className="font-semibold">Challenge</h4>
                    <p className="text-gray-600">
                      NEOM required a reliable, high-capacity energy storage solution that could integrate with renewable sources and operate in extreme desert conditions.
                    </p>
                  </div>
                  
                  <div className="border-l-4 border-[#34D399] pl-4">
                    <h4 className="font-semibold">Solution</h4>
                    <p className="text-gray-600">
                      Customized EnPack units with enhanced thermal management and remote monitoring capabilities.
                    </p>
                  </div>
                  
                  <div className="border-l-4 border-[#34D399] pl-4">
                    <h4 className="font-semibold">Results</h4>
                    <p className="text-gray-600">
                      30% reduction in energy costs, 40% smaller footprint than competing solutions, and reliable performance in temperatures up to 50°C.
                    </p>
                  </div>
                </div>
                
                <Button variant="primary">
                  Read Full Case Study
                </Button>
              </div>
              
              <div className="grid grid-cols-2 gap-2">
                <img 
                  src="https://i.ibb.co/ynp9L5hV/En-Pack-Saudi-Case-1.jpg" 
                  alt="NEOM Project 1" 
                  className="w-full h-full object-cover"
                />
                <img 
                  src="https://i.ibb.co/nqgT3rXd/En-Pack-Saudi-Case-2.jpg" 
                  alt="NEOM Project 2" 
                  className="w-full h-full object-cover"
                />
                <img 
                  src="https://i.ibb.co/ZRWSMqvn/En-Pack-Saudi-Case-3.jpg" 
                  alt="NEOM Project 3" 
                  className="w-full h-full object-cover"
                />
                <img 
                  src="https://i.ibb.co/rftJNqXS/En-Pack-Saudi-Case-4.jpg" 
                  alt="NEOM Project 4" 
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Industry Applications */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Industry Applications
            </h2>
            <p className="text-gray-600 max-w-3xl mx-auto">
              Our solid-state battery technology is versatile enough to benefit multiple industries and applications.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="text-center p-6" hoverEffect>
              <div className="bg-[#34D399] bg-opacity-10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-[#34D399]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">Renewable Energy</h3>
              <p className="text-gray-600">
                Efficient storage solutions for solar and wind energy, enabling better grid integration and energy management.
              </p>
            </Card>
            
            <Card className="text-center p-6" hoverEffect>
              <div className="bg-[#34D399] bg-opacity-10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-[#34D399]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">Commercial Buildings</h3>
              <p className="text-gray-600">
                Reduce energy costs and provide backup power for commercial facilities with our scalable storage solutions.
              </p>
            </Card>
            
            <Card className="text-center p-6" hoverEffect>
              <div className="bg-[#34D399] bg-opacity-10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-[#34D399]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">Electric Vehicles</h3>
              <p className="text-gray-600">
                Higher energy density and faster charging capabilities for the next generation of electric vehicles.
              </p>
            </Card>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-16 bg-[#111827] text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Ready to Start Your Project?
            </h2>
            <p className="text-xl mb-8">
              Contact us today to discuss how our solid-state battery solutions can benefit your specific application.
            </p>
            <Button variant="primary" size="lg">
              <Link to="/contact">Contact Our Team</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Projects;