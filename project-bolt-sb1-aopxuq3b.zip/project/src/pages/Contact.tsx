import React from 'react';
import { MapPin, Mail, Phone, Clock } from 'lucide-react';
import ContactForm from '../components/ui/ContactForm';
import { COMPANY_ADDRESS, CONTACT_EMAIL, CONTACT_PHONE } from '../utils/constants';

const Contact: React.FC = () => {
  return (
    <div>
      {/* Hero Section */}
      <section className="bg-[#111827] py-20 md:py-28">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Contact Us
            </h1>
            <p className="text-xl text-gray-300">
              Have questions about our products or services? We're here to help.
            </p>
          </div>
        </div>
      </section>
      
      {/* Contact Content */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Information */}
            <div>
              <h2 className="text-3xl font-bold mb-8">Get in Touch</h2>
              
              <div className="space-y-8">
                <div className="flex items-start">
                  <div className="bg-[#34D399] bg-opacity-10 w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0 mr-4">
                    <MapPin size={24} className="text-[#34D399]" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold mb-2">Our Location</h3>
                    <p className="text-gray-600">{COMPANY_ADDRESS}</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="bg-[#34D399] bg-opacity-10 w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0 mr-4">
                    <Mail size={24} className="text-[#34D399]" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold mb-2">Email Us</h3>
                    <p className="text-gray-600">
                      <a href={`mailto:${CONTACT_EMAIL}`} className="hover:text-[#34D399] transition-colors">
                        {CONTACT_EMAIL}
                      </a>
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="bg-[#34D399] bg-opacity-10 w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0 mr-4">
                    <Phone size={24} className="text-[#34D399]" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold mb-2">Call Us</h3>
                    <p className="text-gray-600">
                      <a href={`tel:${CONTACT_PHONE}`} className="hover:text-[#34D399] transition-colors">
                        {CONTACT_PHONE}
                      </a>
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="bg-[#34D399] bg-opacity-10 w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0 mr-4">
                    <Clock size={24} className="text-[#34D399]" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold mb-2">Business Hours</h3>
                    <p className="text-gray-600">Monday - Friday: 9:00 AM - 5:00 PM</p>
                    <p className="text-gray-600">Saturday - Sunday: Closed</p>
                  </div>
                </div>
              </div>
              
              {/* Social Media Links */}
              <div className="mt-10">
                <h3 className="text-lg font-semibold mb-4">Connect With Us</h3>
                <div className="flex space-x-4">
                  <a 
                    href="#" 
                    className="bg-[#111827] text-white w-10 h-10 rounded-full flex items-center justify-center hover:bg-[#34D399] transition-colors"
                    aria-label="Facebook"
                  >
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M18.77,7.46H14.5v-1.9c0-.9.6-1.1,1-1.1h3V.5L14.84.5C10.44.5,9.63,3.13,9.63,5.3V7.46H8v3.93H9.63V22.5H14.5V11.39h2.95Z" />
                    </svg>
                  </a>
                  <a 
                    href="#" 
                    className="bg-[#111827] text-white w-10 h-10 rounded-full flex items-center justify-center hover:bg-[#34D399] transition-colors"
                    aria-label="Twitter"
                  >
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M23.32,6.44c-.84.37-1.74.62-2.68.73a4.67,4.67,0,0,0,2.05-2.58,9.33,9.33,0,0,1-2.95,1.13,4.67,4.67,0,0,0-8,4.26,13.26,13.26,0,0,1-9.64-4.89,4.67,4.67,0,0,0,1.44,6.22,4.66,4.66,0,0,1-2.11-.58v.06a4.67,4.67,0,0,0,3.75,4.58,4.65,4.65,0,0,1-2.11.08,4.67,4.67,0,0,0,4.36,3.24,9.37,9.37,0,0,1-5.78,2,9.49,9.49,0,0,1-1.11-.07,13.2,13.2,0,0,0,7.14,2.09,13.18,13.18,0,0,0,13.27-13.3c0-.2,0-.4,0-.6A9.47,9.47,0,0,0,23.32,6.44Z" />
                    </svg>
                  </a>
                  <a 
                    href="#" 
                    className="bg-[#111827] text-white w-10 h-10 rounded-full flex items-center justify-center hover:bg-[#34D399] transition-colors"
                    aria-label="LinkedIn"
                  >
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M19.87,3.13H4.13A1,1,0,0,0,3.13,4.13V19.87a1,1,0,0,0,1,1H19.87a1,1,0,0,0,1-1V4.13A1,1,0,0,0,19.87,3.13ZM9,17.75H6.25V9H9Zm-1.38-9.9A1.62,1.62,0,1,1,9.25,6.23,1.63,1.63,0,0,1,7.62,7.85ZM18,17.75H15.25v-4.1c0-1.12,0-2.55-1.55-2.55S12,12.2,12,13.25v4.5H9.25v-8.5H11.5V10.5h0a3.14,3.14,0,0,1,2.83-1.55C17.5,8.95,18,10.25,18,12V17.75Z" />
                    </svg>
                  </a>
                  <a 
                    href="#" 
                    className="bg-[#111827] text-white w-10 h-10 rounded-full flex items-center justify-center hover:bg-[#34D399] transition-colors"
                    aria-label="Instagram"
                  >
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12,2.16c3.2,0,3.58,0,4.85.07,3.25.15,4.77,1.69,4.92,4.92.06,1.27.07,1.65.07,4.85s0,3.58-.07,4.85c-.15,3.23-1.66,4.77-4.92,4.92-1.27.06-1.64.07-4.85.07s-3.58,0-4.85-.07c-3.26-.15-4.77-1.7-4.92-4.92-.06-1.27-.07-1.64-.07-4.85s0-3.58.07-4.85C2.38,3.92,3.9,2.38,7.15,2.23,8.42,2.18,8.8,2.16,12,2.16ZM12,0C8.74,0,8.33,0,7.05.07c-4.35.2-6.78,2.62-7,7C0,8.33,0,8.74,0,12S0,15.67.07,17c.2,4.36,2.62,6.78,7,7C8.33,24,8.74,24,12,24s3.67,0,4.95-.07c4.35-.2,6.78-2.62,7-7C24,15.67,24,15.26,24,12s0-3.67-.07-4.95c-.2-4.35-2.62-6.78-7-7C15.67,0,15.26,0,12,0Zm0,5.84A6.16,6.16,0,1,0,18.16,12,6.16,6.16,0,0,0,12,5.84ZM12,16a4,4,0,1,1,4-4A4,4,0,0,1,12,16ZM18.41,4.15A1.44,1.44,0,1,0,19.85,5.59,1.44,1.44,0,0,0,18.41,4.15Z" />
                    </svg>
                  </a>
                </div>
              </div>
            </div>
            
            {/* Contact Form */}
            <div>
              <ContactForm />
            </div>
          </div>
        </div>
      </section>
      
      {/* Map Section */}
      <section className="py-0">
        <div className="h-96 w-full">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d92253.06872005731!2d-79.42346562159868!3d43.718403208308126!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89d4cb90d7c63ba5%3A0x323555502ab4c477!2sToronto%2C%20ON%2C%20Canada!5e0!3m2!1sen!2sus!4v1683123456789!5m2!1sen!2sus"
            width="100%"
            height="100%"
            style={{ border: 0 }}
            allowFullScreen
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            title="Google Maps"
          ></iframe>
        </div>
      </section>
    </div>
  );
};

export default Contact;