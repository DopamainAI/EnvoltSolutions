import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import Button from '../ui/Button';

const Header: React.FC = () => {
  const location = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState<string | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location]);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const toggleDropdown = (name: string) => {
    setDropdownOpen(prev => prev === name ? null : name);
  };

  const headerClass = `fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
    isScrolled ? 'bg-[#111827]/90 shadow-md py-3' : 'bg-transparent py-5'
  }`;

  const navLinks = [
    { name: 'Home', path: '/' },
    {
      name: 'Products',
      path: '/products',
      dropdown: [
        { name: 'EnWall', path: '/products/enwall' },
        { name: 'EnCap', path: '/products/encap' },
        { name: 'EnSaga', path: '/products/ensaga' },
        { name: 'EnPack', path: '/products/enpack' },
      ],
    },
    { name: 'Projects', path: '/projects' },
    { name: 'About Us', path: '/about' },
    { name: 'FAQ', path: '/faq' },
    { name: 'Contact', path: '/contact' },
  ];

  const isActive = (path: string) => {
    if (path === '/') return location.pathname === '/';
    return location.pathname.startsWith(path);
  };

  return (
    <header className={headerClass}>
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center">
          <Link to="/" className="flex items-center">
            <img 
              src="https://i.ibb.co/v6CF48Jp/Envolt-Horizontal-White-Blk-BG.png" 
              alt="Envolt Solutions Logo" 
              className="h-10"
            />
          </Link>

          <nav className="hidden lg:flex items-center space-x-6">
            {navLinks.map(link => (
              <div key={link.name} className="relative group">
                {link.dropdown ? (
                  <button
                    className={`text-white font-medium hover:text-[#34D399] transition-colors py-2 flex items-center ${
                      isActive(link.path) ? 'text-[#34D399]' : ''
                    }`}
                    onClick={() => toggleDropdown(link.name)}
                    onMouseEnter={() => setDropdownOpen(link.name)}
                    onMouseLeave={() => setDropdownOpen(null)}
                  >
                    {link.name}
                    <svg 
                      className="ml-1 w-4 h-4" 
                      fill="none" 
                      stroke="currentColor" 
                      viewBox="0 0 24 24"
                    >
                      <path 
                        strokeLinecap="round" 
                        strokeLinejoin="round" 
                        strokeWidth={2} 
                        d="M19 9l-7 7-7-7"
                      />
                    </svg>
                  </button>
                ) : (
                  <Link
                    to={link.path}
                    className={`text-white font-medium hover:text-[#34D399] transition-colors py-2 ${
                      isActive(link.path) ? 'text-[#34D399]' : ''
                    }`}
                  >
                    {link.name}
                  </Link>
                )}

                {link.dropdown && (
                  <div
                    className={`absolute top-full left-0 w-48 bg-white/80 backdrop-blur-md rounded-md shadow-lg py-1 transition-all duration-200 ${
                      dropdownOpen === link.name
                        ? 'opacity-100 visible translate-y-0'
                        : 'opacity-0 invisible -translate-y-4'
                    }`}
                    onMouseEnter={() => setDropdownOpen(link.name)}
                    onMouseLeave={() => setDropdownOpen(null)}
                  >
                    {link.dropdown.map(item => (
                      <Link
                        key={item.name}
                        to={item.path}
                        className="block px-4 py-2 text-sm text-gray-800 hover:bg-gray-100 hover:text-[#34D399]"
                      >
                        {item.name}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ))}

            <Button variant="primary" size="sm">
              Get a Quote
            </Button>
          </nav>

          <button
            className="lg:hidden text-white focus:outline-none"
            onClick={toggleMenu}
            aria-label={isMenuOpen ? 'Close menu' : 'Open menu'}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      <div
        className={`fixed inset-0 bg-[#111827]/95 z-40 lg:hidden transition-transform duration-300 ease-in-out ${
          isMenuOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="flex flex-col h-full p-6 pt-20">
          {navLinks.map(link => (
            <div key={link.name} className="mb-4">
              {link.dropdown ? (
                <div>
                  <button
                    className={`text-xl text-white font-medium mb-2 flex items-center ${
                      isActive(link.path) ? 'text-[#34D399]' : ''
                    }`}
                    onClick={() => toggleDropdown(link.name)}
                  >
                    {link.name}
                    <svg 
                      className={`ml-2 w-5 h-5 transition-transform ${
                        dropdownOpen === link.name ? 'rotate-180' : ''
                      }`} 
                      fill="none" 
                      stroke="currentColor" 
                      viewBox="0 0 24 24"
                    >
                      <path 
                        strokeLinecap="round" 
                        strokeLinejoin="round" 
                        strokeWidth={2} 
                        d="M19 9l-7 7-7-7"
                      />
                    </svg>
                  </button>

                  {dropdownOpen === link.name && (
                    <div className="ml-4 space-y-2">
                      {link.dropdown.map(item => (
                        <Link
                          key={item.name}
                          to={item.path}
                          className="block text-white hover:text-[#34D399] py-1"
                        >
                          {item.name}
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <Link
                  to={link.path}
                  className={`text-xl text-white font-medium block py-2 ${
                    isActive(link.path) ? 'text-[#34D399]' : ''
                  }`}
                >
                  {link.name}
                </Link>
              )}
            </div>
          ))}

          <div className="mt-8">
            <Button variant="primary" fullWidth>
              Get a Quote
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
