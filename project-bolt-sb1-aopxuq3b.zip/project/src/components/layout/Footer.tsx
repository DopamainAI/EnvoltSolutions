import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Facebook, 
  Twitter, 
  Instagram, 
  Linkedin, 
  Mail, 
  Phone, 
  MapPin 
} from 'lucide-react';
import { COMPANY_ADDRESS, CONTACT_EMAIL, CONTACT_PHONE } from '../../utils/constants';

const Footer: React.FC = () => {
  return (
    <footer className="bg-[#111827] text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <img 
              src="https://i.ibb.co/v6CF48Jp/Envolt-Horizontal-White-Blk-BG.png" 
              alt="Envolt Solutions Logo" 
              className="h-10 mb-6"
            />
            <p className="text-gray-300 mb-6">
              Revolutionizing energy storage with advanced solid-state battery technology.
            </p>
            <div className="flex space-x-4">
              <a 
                href="#" 
                className="text-gray-400 hover:text-[#34D399] transition-colors"
                aria-label="Facebook"
              >
                <Facebook size={20} />
              </a>
              <a 
                href="#" 
                className="text-gray-400 hover:text-[#34D399] transition-colors"
                aria-label="Twitter"
              >
                <Twitter size={20} />
              </a>
              <a 
                href="#" 
                className="text-gray-400 hover:text-[#34D399] transition-colors"
                aria-label="Instagram"
              >
                <Instagram size={20} />
              </a>
              <a 
                href="#" 
                className="text-gray-400 hover:text-[#34D399] transition-colors"
                aria-label="LinkedIn"
              >
                <Linkedin size={20} />
              </a>
            </div>
          </div>
          
          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-3">
              <li>
                <Link to="/" className="text-gray-300 hover:text-[#34D399] transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/products" className="text-gray-300 hover:text-[#34D399] transition-colors">
                  Products
                </Link>
              </li>
              <li>
                <Link to="/projects" className="text-gray-300 hover:text-[#34D399] transition-colors">
                  Projects
                </Link>
              </li>
              <li>
                <Link to="/about" className="text-gray-300 hover:text-[#34D399] transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link to="/faq" className="text-gray-300 hover:text-[#34D399] transition-colors">
                  FAQ
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-gray-300 hover:text-[#34D399] transition-colors">
                  Contact
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Products */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Products</h3>
            <ul className="space-y-3">
              <li>
                <Link to="/products/enwall" className="text-gray-300 hover:text-[#34D399] transition-colors">
                  EnWall
                </Link>
              </li>
              <li>
                <Link to="/products/encap" className="text-gray-300 hover:text-[#34D399] transition-colors">
                  EnCap
                </Link>
              </li>
              <li>
                <Link to="/products/ensaga" className="text-gray-300 hover:text-[#34D399] transition-colors">
                  EnSaga
                </Link>
              </li>
              <li>
                <Link to="/products/enpack" className="text-gray-300 hover:text-[#34D399] transition-colors">
                  EnPack
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <MapPin size={20} className="text-[#34D399] mr-3 mt-1 flex-shrink-0" />
                <span className="text-gray-300">{COMPANY_ADDRESS}</span>
              </li>
              <li className="flex items-center">
                <Phone size={20} className="text-[#34D399] mr-3 flex-shrink-0" />
                <a href={`tel:${CONTACT_PHONE}`} className="text-gray-300 hover:text-[#34D399] transition-colors">
                  {CONTACT_PHONE}
                </a>
              </li>
              <li className="flex items-center">
                <Mail size={20} className="text-[#34D399] mr-3 flex-shrink-0" />
                <a href={`mailto:${CONTACT_EMAIL}`} className="text-gray-300 hover:text-[#34D399] transition-colors">
                  {CONTACT_EMAIL}
                </a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-10 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm mb-4 md:mb-0">
            &copy; {new Date().getFullYear()} Envolt Solutions. All rights reserved.
          </p>
          <div className="flex space-x-6">
            <Link to="/privacy-policy" className="text-gray-400 text-sm hover:text-[#34D399] transition-colors">
              Privacy Policy
            </Link>
            <Link to="/terms-of-service" className="text-gray-400 text-sm hover:text-[#34D399] transition-colors">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;