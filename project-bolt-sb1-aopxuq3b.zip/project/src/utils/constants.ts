import { Product, Project, FAQ, TeamMember } from '../types';

export const COMPANY_NAME = 'Envolt Solutions';
export const COMPANY_TAGLINE = 'The Future of Battery Technology';
export const COMPANY_DESCRIPTION = 'Revolutionizing energy storage with advanced solid-state battery technology';
export const CONTACT_EMAIL = 'info@envoltsolutions.com';
export const CONTACT_PHONE = '+1 (403) 928 4355';
export const COMPANY_ADDRESS = '206 Muir Cres NW, Medicine Hat, Alberta, Canada';

export const COLORS = {
  primary: '#34D399', // Green from logo
  dark: '#111827',
  light: '#F9FAFB',
  white: '#FFFFFF',
  gray: '#6B7280',
};

export const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'EnWall',
    shortDescription: 'Advanced wall-mounted energy storage solution',
    longDescription: 'EnWall is our flagship wall-mounted energy storage solution, designed for residential and commercial applications. It offers superior energy density, longer lifespan, and enhanced safety compared to traditional lithium-ion batteries.',
    features: [
      'Solid-state technology for enhanced safety',
      'Up to 15 years lifespan',
      'Higher energy density than lithium-ion',
      'Wall-mounted for space efficiency',
      'Environmentally friendly materials'
    ],
    image: 'https://i.ibb.co/bgJ8fVjz/En-Wall-Img-1.png',
    slug: 'enwall'
  },
  {
    id: '2',
    name: 'EnCap',
    shortDescription: 'Compact energy storage for portable applications',
    longDescription: 'EnCap provides reliable, compact energy storage for portable and small-scale applications. Our solid-state technology ensures safety, longevity, and high performance in a small form factor.',
    features: [
      'Compact and portable design',
      'Fast charging capabilities',
      'No thermal runaway risk',
      'Longer cycle life than conventional batteries',
      'Wide temperature operation range'
    ],
    image: 'https://i.ibb.co/wZkgpGwq/En-Cap-Img-1.png',
    slug: 'encap'
  },
  {
    id: '3',
    name: 'EnSaga',
    shortDescription: 'Scalable energy solutions for industrial applications',
    longDescription: 'EnSaga is our industrial-grade energy storage system, designed for large-scale applications. It offers unmatched scalability, reliability, and efficiency for businesses with substantial energy needs.',
    features: [
      'Modular and scalable design',
      'Industrial-grade durability',
      'Advanced energy management system',
      'Remote monitoring capabilities',
      'Lower total cost of ownership'
    ],
    image: 'https://i.ibb.co/Hf35C22Y/En-Saga-Img-1.png',
    slug: 'ensaga'
  },
  {
    id: '4',
    name: 'EnPack',
    shortDescription: 'Customizable battery packs for diverse needs',
    longDescription: 'EnPack offers customizable solid-state battery solutions tailored to specific applications. From electric vehicles to specialized equipment, EnPack delivers reliable, safe, and long-lasting energy storage.',
    features: [
      'Customizable configurations',
      'High-density energy storage',
      'Rapid charge and discharge',
      'Enhanced safety features',
      'Environmentally responsible materials'
    ],
    image: 'https://i.ibb.co/Ps36T3bC/En-Pack-Img-1.png',
    slug: 'enpack'
  }
];

export const PROJECTS: Project[] = [
  {
    id: '1',
    title: 'Etisalat Storage Facility',
    description: 'Implementation of EnSaga storage systems for Etisalat\'s telecommunications infrastructure, providing reliable backup power and improved energy efficiency.',
    location: 'United Arab Emirates',
    image: 'https://i.ibb.co/ycg98hdG/Etisalat-Storage.jpg',
    slug: 'etisalat-storage'
  },
  {
    id: '2',
    title: 'Solar Site Installation',
    description: 'Large-scale deployment of EnPack units at a solar farm in the UAE, enabling efficient energy storage and distribution from renewable sources.',
    location: 'United Arab Emirates',
    image: 'https://i.ibb.co/CC9pKsk/Solar-Site-UAE.jpg',
    slug: 'solar-site-uae'
  },
  {
    id: '3',
    title: 'Research Center Energy Solution',
    description: 'Custom EnWall installation at an Italian research facility, providing clean, reliable power for sensitive equipment and research operations.',
    location: 'Italy',
    image: 'https://i.ibb.co/Y7rfT4jg/Italy-Research-Centre.jpg',
    slug: 'italy-research-center'
  },
  {
    id: '4',
    title: 'NEOM Charging Infrastructure',
    description: 'Development of advanced charging stations powered by EnPack technology for NEOM\'s next-generation city infrastructure.',
    location: 'Saudi Arabia',
    image: 'https://i.ibb.co/fsmwSS6/Neom-Charging-Unit.jpg',
    slug: 'neom-charging'
  },
  {
    id: '5',
    title: 'Roadside Assistance Units',
    description: 'Deployment of portable EnCap units for roadside emergency charging services, providing quick, reliable power for stranded electric vehicles.',
    location: 'Canada',
    image: 'https://i.ibb.co/zhYWj5t2/Roadside-Unit-1.png',
    slug: 'roadside-assistance'
  }
];

export const TEAM_MEMBERS: TeamMember[] = [
  {
    id: '1',
    name: 'Dr. Sarah Chen',
    position: 'Chief Technology Officer',
    bio: 'Dr. Chen leads our research and development team with over 15 years of experience in advanced battery technologies and materials science.',
    image: 'https://i.ibb.co/fBxLYm0/pexels-lukas-296236-2048x1356.jpg'
  },
  {
    id: '2',
    name: 'Michael Rodriguez',
    position: 'Chief Executive Officer',
    bio: 'With a background in renewable energy and sustainable technology, Michael drives Envolt\'s mission to revolutionize energy storage solutions worldwide.',
    image: 'https://i.ibb.co/fBxLYm0/pexels-lukas-296236-2048x1356.jpg'
  },
  {
    id: '3',
    name: 'Jennifer Park',
    position: 'Head of Product Development',
    bio: 'Jennifer oversees our product lifecycle from concept to market, ensuring our solutions meet the highest standards of quality and performance.',
    image: 'https://i.ibb.co/fBxLYm0/pexels-lukas-296236-2048x1356.jpg'
  }
];

export const FAQS: FAQ[] = [
  {
    id: '1',
    question: 'What makes solid-state batteries better than lithium-ion batteries?',
    answer: 'Solid-state batteries offer numerous advantages over traditional lithium-ion batteries, including higher energy density, longer lifespan, faster charging capabilities, enhanced safety with no risk of thermal runaway or fires, and greater environmental sustainability.',
    category: 'Technology'
  },
  {
    id: '2',
    question: 'How long do Envolt\'s batteries typically last?',
    answer: 'Our solid-state batteries are designed to last significantly longer than conventional lithium-ion batteries. Depending on the specific product and usage patterns, our batteries typically maintain over 80% capacity for 10-15 years, compared to 3-5 years for traditional batteries.',
    category: 'Products'
  },
  {
    id: '3',
    question: 'Are your batteries environmentally friendly?',
    answer: 'Yes, sustainability is a core focus for Envolt Solutions. Our solid-state batteries eliminate many of the harmful materials found in conventional batteries, have a longer lifespan (reducing waste), and are designed with recyclability in mind.',
    category: 'Environment'
  },
  {
    id: '4',
    question: 'Can Envolt batteries be used in electric vehicles?',
    answer: 'Yes, our EnPack product line is specifically designed for electric vehicle applications, offering higher energy density, faster charging, and enhanced safety compared to conventional lithium-ion batteries.',
    category: 'Applications'
  },
  {
    id: '5',
    question: 'Do you offer customized solutions?',
    answer: 'Absolutely. We work closely with clients to understand their specific energy storage needs and can customize our products accordingly. Our EnSaga and EnPack lines are particularly adaptable to custom requirements.',
    category: 'Services'
  }
];